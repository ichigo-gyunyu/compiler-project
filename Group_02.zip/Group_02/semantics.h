
/**
 * Group 2
 * Sanjeet Kapadia   2018B4A70137P
 * Lingesh Kumaar    2018B4A70857P
 * Aman Mishra       2018B4A70877P
 * Sidharth Varghese 2019A7PS1133P
 * Edara Bala Mukesh 2019A7PS0081P
 */

#ifndef SEMANTICS_H
#define SEMANTICS_H

#include "ast.h"
#include "symbolTable.h"

/**
 * Perform semantic analysis
 */
void checkSemantics(const AST ast);

extern bool semantic_error; // if semantic errors exist

#endif
